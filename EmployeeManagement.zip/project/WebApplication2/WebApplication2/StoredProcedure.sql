﻿CREATE PROCEDURE sp_ManageEmployeeDetailedInfo
    @Id INT = NULL,
    @Name NVARCHAR(100) = NULL,
    @Email NVARCHAR(100) = NULL,
    @DateOfBirth DATE = NULL,
    @Gender NVARCHAR(10) = NULL,
    @Qualification NVARCHAR(200) = NULL,
    @Image NVARCHAR(255) = NULL,
    @Action NVARCHAR(10)
AS
BEGIN
    SET NOCOUNT ON;

    IF @Action = 'Insert'
    BEGIN
        INSERT INTO EmployeeDetailedInfo ( Name, Email, DateOfBirth, Gender, Qualification, Image)
        VALUES (@Name, @Email, @DateOfBirth, @Gender, @Qualification, @Image);
    END
    ELSE IF @Action = 'Update'
    BEGIN
        UPDATE EmployeeDetailedInfo
        SET Name = @Name,
            Email = @Email,
            DateOfBirth = @DateOfBirth,
            Gender = @Gender,
            Qualification = @Qualification,
            Image = @Image
        WHERE Id = @Id;
    END
    ELSE IF @Action = 'Delete'
    BEGIN
        DELETE FROM EmployeeDetailedInfo WHERE Id = @Id;
    END
    ELSE IF @Action = 'SelectAll'
    BEGIN
        SELECT * FROM EmployeeDetailedInfo;
    END
    ELSE IF @Action = 'SelectById'
    BEGIN
        SELECT * FROM EmployeeDetailedInfo WHERE Id = @Id;
    END
END;



