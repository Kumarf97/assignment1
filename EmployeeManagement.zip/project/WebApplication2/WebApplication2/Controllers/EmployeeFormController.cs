﻿using EmployeeManagement.Models;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Configuration;


namespace WebApplication2.Controllers
{
    [Route("EmployeeForm")]
    public class EmployeeFormController : Controller
    {
        private readonly string connStr;
        private readonly IHostEnvironment _env;

        public EmployeeFormController(IConfiguration configuration, IHostEnvironment env)
        {
            connStr = configuration.GetConnectionString("YourConnectionString");
            _env = env;
        }

        public ActionResult Index()
        {
            var employees = GetEmployeesData(); 
            return View(employees); 
        }

        [HttpGet("GetEmployees")]
        public JsonResult GetEmployeesData()
        {
            using (var con = new SqlConnection(connStr))
            using (var cmd = new SqlCommand("dbo.sp_ManageEmployeeDetailedInfo", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Action", "SelectAll");
                con.Open();
                var reader = cmd.ExecuteReader();
                var employees = new List<EmployeeDetails>();
                while (reader.Read())
                {
                    employees.Add(new EmployeeDetails
                    {
                        ID = (int)reader["Id"],
                        Name = reader["Name"].ToString(),
                        Email = reader["Email"].ToString(),
                        DateOfBirth = (DateTime)reader["DateOfBirth"],
                        Gender = reader["Gender"].ToString(),
                        Qualification = reader["Qualification"].ToString(),
                        Image = reader["Image"].ToString()
                    });
                }
                return Json(employees);
            }
        }
        [HttpGet("GetEmployeeById")]
        public JsonResult GetEmployeeById(int id)
        {
            using (var con = new SqlConnection(connStr))
            using (var cmd = new SqlCommand("dbo.sp_ManageEmployeeDetailedInfo", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.Parameters.AddWithValue("@Action", "SelectById");
                con.Open();
                var reader = cmd.ExecuteReader();
                var employees = new EmployeeDetails();
                if (reader.Read())
                {
                    employees = new EmployeeDetails
                    {
                        ID = (int)reader["Id"],
                        Name = reader["Name"].ToString(),
                        Email = reader["Email"].ToString(),
                        DateOfBirth = (DateTime)reader["DateOfBirth"],
                        Gender = reader["Gender"].ToString(),
                        Qualification = reader["Qualification"].ToString(),
                        Image = reader["Image"].ToString()
                    };
                }
                return Json(employees);
            }
        }

        [HttpPost("SaveEmployee")]
        public JsonResult SaveEmployee(EmployeeDetails emp, IFormFile file = null)
        {
            string imgPath = null;

            // If the file is not null, save it to a folder and get the path
            if (file != null && file.Length > 0)
            {
                var path = Guid.NewGuid().ToString() + System.IO.Path.GetExtension(file.FileName); ;
                imgPath = "Uploads/Images/" + path;
                string appRoot = _env.ContentRootPath;
               
                string filePath = Path.Combine(appRoot, "wwwroot", "Uploads", "Images", path);
                var directory = Path.GetDirectoryName(filePath);
                if (!Directory.Exists(directory))
                {
                    Directory.CreateDirectory(directory);
                }

                // Save the file to the server
                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    file.CopyTo(stream);
                }
            }

            using (var con = new SqlConnection(connStr))
            using (var cmd = new SqlCommand("dbo.sp_ManageEmployeeDetailedInfo", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", emp.ID);
                cmd.Parameters.AddWithValue("@Name", emp.Name);
                cmd.Parameters.AddWithValue("@Email", emp.Email);
                cmd.Parameters.AddWithValue("@DateOfBirth", emp.DateOfBirth);
                cmd.Parameters.AddWithValue("@Gender", emp.Gender);
                cmd.Parameters.AddWithValue("@Qualification", emp.Qualification);
                cmd.Parameters.AddWithValue("@Image", imgPath ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@Action", emp.ID > 0 ? "Update" : "Insert");
                con.Open();
                cmd.ExecuteNonQuery();
            }
            GetEmployeesData();
            return Json(new { success = true, message = "Employee saved successfully." });
        }

        [HttpPost("DeleteEmployee")]
        public JsonResult DeleteEmployee(int id)
        {
            using (var con = new SqlConnection(connStr))
            using (var cmd = new SqlCommand("dbo.sp_ManageEmployeeDetailedInfo", con))
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.Parameters.AddWithValue("@Action", "Delete");
                con.Open();
                cmd.ExecuteNonQuery();
            }
            return Json(new { success = true, message = "Employee deleted successfully." });
        }
    }
}
